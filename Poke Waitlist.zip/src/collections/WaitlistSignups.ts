import type { Access, CollectionConfig } from 'payload'

const isPayloadAdmin: Access = ({ req }) => req.user?.collection === 'admins'

export const WaitlistSignups: CollectionConfig = {
  slug: 'waitlist-signups',
  access: {
    create: () => true,
    delete: isPayloadAdmin,
    read: isPayloadAdmin,
    update: isPayloadAdmin,
  },
  admin: {
    defaultColumns: ['email', 'source', 'createdAt'],
    group: 'Leads',
    useAsTitle: 'email',
  },
  fields: [
    {
      name: 'email',
      type: 'email',
      index: true,
      required: true,
      unique: true,
      hooks: {
        beforeValidate: [
          ({ value }) => (typeof value === 'string' ? value.trim().toLowerCase() : value),
        ],
      },
    },
    {
      name: 'source',
      type: 'select',
      options: [
        { label: 'Hero form', value: 'hero' },
        { label: 'Final call to action', value: 'final' },
      ],
      required: true,
    },
  ],
  timestamps: true,
  versions: false,
}
